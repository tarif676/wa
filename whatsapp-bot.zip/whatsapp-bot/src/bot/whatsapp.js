const { Client, LocalAuth } = require('whatsapp-web.js');
const { handleMessage } = require('./handler');

process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught exception:', err.message);
});

process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled rejection:', err?.message || err);
});

const args = [
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-dev-shm-usage',
  '--disable-accelerated-2d-canvas',
  '--no-first-run',
  '--no-zygote',
  '--disable-gpu',
  '--disable-blink-features=AutomationControlled',
  '--disable-features=IsolateOrigins,site-per-process',
  '--window-size=1280,720',
];

const client = new Client({
  authStrategy: new LocalAuth({ dataPath: '.wwebjs_auth' }),
  puppeteer: {
    headless: true,
    executablePath: '/home/codespace/.cache/puppeteer/chrome/linux-121.0.6167.85/chrome-linux64/chrome',
    args,
    defaultViewport: { width: 1280, height: 720 },
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  },
});

const botState = { status: 'offline', startTime: null, botWid: null, lidMap: {} };

function setBotStatus(status) {
  botState.status = status;
  if (status === 'online') botState.startTime = Date.now();
}

let onlineInterval = null;

function cleanWid(id) {
  return String(id).replace(/@c\.us/, '').replace(/@lid/, '').replace(/@g\.us/, '');
}

// Lazy LID resolver — looks up a single contact on demand
async function resolveLid(senderId) {
  try {
    const contact = await client.getContactById(senderId);
    if (contact && contact.number) {
      const phone = contact.number.replace(/\D/g, '');
      const lid = cleanWid(senderId);
      if (phone && lid) {
        botState.lidMap[lid] = phone;
        botState.lidMap[phone] = lid;
        return phone;
      }
    }
  } catch (e) {}
  return null;
}

client.on('loading_screen', (percent, message) => {
  console.log(`🔄 Loading: ${percent}% - ${message}`);
});

client.on('qr', async (qr) => {
  console.log('\n📱 QR ready — pair from Admin Panel → WhatsApp Login');
});

client.on('authenticated', () => {
  console.log('✅ WhatsApp authenticated!');
});

client.on('auth_failure', (msg) => {
  console.error('❌ Auth failed:', msg);
  console.log('🔄 Restarting in 5s...');
  setTimeout(() => client.initialize(), 5000);
});

client.on('ready', async () => {
  const wid = client.info.wid;
  const botWid = wid._serialized || wid;
  botState.botWid = botWid;
  botState.status = 'online';
  botState.startTime = Date.now();
  console.log(`🟢 Bot ONLINE! WID: ${botWid}`);

  try { await client.sendPresenceAvailable(); } catch (e) {}

  if (onlineInterval) clearInterval(onlineInterval);
  onlineInterval = setInterval(async () => {
    try { await client.sendPresenceAvailable(); } catch (e) {}
  }, 120000);
});

client.on('disconnected', (reason) => {
  console.log('🔴 Disconnected:', reason);
  botState.status = 'offline';
  if (onlineInterval) clearInterval(onlineInterval);
  console.log('🔄 Reconnecting in 5s...');
  setTimeout(() => client.initialize(), 5000);
});

client.on('message', async (message) => {
  await handleMessage(message, client);
});

module.exports = { client, botState, setBotStatus, resolveLid };
