# WhatsApp AI Auto-Reply Bot

## Prerequisites
- Node.js v18 or higher
- A WhatsApp account (will be linked as a linked device)
- Google Gemini API key (free at aistudio.google.com)

## Installation

1. Clone or copy project files
2. Run: `npm install`
3. Copy `.env` file and update `SESSION_SECRET` with a random 32+ character string
4. Run: `node index.js`

## First Run

1. Terminal will show Admin Panel URL
2. You'll be prompted to enter your phone number
3. A PAIRING CODE will be displayed
4. On your phone: WhatsApp → Settings → Linked Devices → Link a Device → Link with Phone Number
5. Enter the pairing code
6. Bot will show "ONLINE and ready!"

## Admin Panel

- URL: http://localhost:3001/admin
- Default password: `admin123`
- **CHANGE THE PASSWORD after first login!**

## Adding Gemini API Key

1. Go to Admin Panel → API Keys tab
2. Click "Add New Key"
3. Enter your Gemini API key from aistudio.google.com
4. Keep default endpoint and model, or customize
5. Click "Add Key"

## Important Notes

- The bot adds ~6 second delay before replying (human-like behavior)
- Keep the terminal running for the bot to work
- Session is saved — no need to re-login after restart
- Group replies are DISABLED by default — enable in Reply Settings if needed
