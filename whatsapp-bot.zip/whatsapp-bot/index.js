require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { readJSON, writeJSON } = require('./src/storage/store');
const createAdminServer = require('./src/admin/server');

function killStaleChrome() {
  try { require('child_process').execSync('killall -9 chrome chromium chromium-browser 2>/dev/null', { stdio: 'ignore' }); } catch (e) {}
}

function autoClean() {
  killStaleChrome();

  const clean = [
    { dir: '.wwebjs_cache', label: 'WhatsApp cache' },
  ];

  for (const c of clean) {
    const p = path.join(__dirname, c.dir);
    if (fs.existsSync(p)) {
      try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) {}
    }
  }

  const authDir = path.join(__dirname, '.wwebjs_auth', 'session');
  if (fs.existsSync(authDir)) {
    const lockFiles = fs.readdirSync(authDir).filter(f => f.endsWith('.lock') || f === 'SingletonLock' || f === 'SingletonSocket' || f === 'SingletonCookie');
    for (const lf of lockFiles) {
      try { fs.unlinkSync(path.join(authDir, lf)); } catch (e) {}
    }
  }
}

async function initDataFiles() {
  let config = readJSON('config.json');
  if (!config) {
    const defaultPassword = process.env.DEFAULT_ADMIN_PASSWORD || 'admin123';
    const hash = await bcrypt.hash(defaultPassword, 10);
    config = {
      adminPasswordHash: hash,
      botPrompt: 'You are a helpful WhatsApp assistant. Reply naturally and concisely. Be friendly.',
      replyToInbox: true,
      replyToGroups: false,
      botName: 'AI Assistant',
      botEnabled: true
    };
    writeJSON('config.json', config);
    console.log('📁 Created default config.json');
  }

  if (!readJSON('apikeys.json')) {
    writeJSON('apikeys.json', []);
    console.log('📁 Created empty apikeys.json');
  }

  if (!readJSON('blocklist.json')) {
    writeJSON('blocklist.json', { numbers: [], groups: [] });
    console.log('📁 Created empty blocklist.json');
  }

  if (!readJSON('adminusers.json') || !Array.isArray(readJSON('adminusers.json'))) {
    writeJSON('adminusers.json', []);
    console.log('📁 Created empty adminusers.json');
  }
}

async function main() {
  autoClean();

  console.log('\n' + '═'.repeat(55));
  console.log('   🤖 WhatsApp AI Auto-Reply Bot');
  console.log('═'.repeat(55) + '\n');

  await initDataFiles();

  const { botState, setBotStatus, client } = require('./src/bot/whatsapp');

  const adminPort = parseInt(process.env.ADMIN_PORT) || 3001;
  const adminApp = createAdminServer(botState, client);
  adminApp.listen(adminPort, () => {
    console.log('🌐 Admin Panel: http://localhost:' + adminPort + '/admin');
    console.log('🔐 Default password: ' + (process.env.DEFAULT_ADMIN_PASSWORD || 'admin123'));
    console.log('   (Change this password after first login!)\n');
  });

  console.log('📱 Starting WhatsApp client...\n');

  try {
    await client.initialize();
  } catch (e) {
    console.error('❌ Client init error:', e.message);
    console.log('🔄 Retrying in 10s...');
    setTimeout(() => client.initialize().catch(e2 => console.error('❌ Retry failed:', e2.message)), 10000);
  }
}

main().catch(console.error);
